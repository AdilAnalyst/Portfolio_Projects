--select Distinct customer_id
--from dbo.CustomerTable
--where SUBSTRING(country,1,2) = 'US'

--select Distinct customer_id
--from dbo.CustomerTable
--where
--	trim(state) = 'OH'

--Select *
--from automobile_data

--select distinct fuel_type
--from automobile_data 

--select min(length) as Min_length, max(length) as Max_length
--from automobile_data

--Select *
--from automobile_data
--where make = 'dodge'and fuel_type = 'gas' and body_style = 'sedan'


--update automobile_data
--set 
--	num_of_doors = 'four'
--where
--make = 'dodge'and fuel_type = 'gas' and body_style = 'sedan'


--Select *
--from automobile_data
--where compression_ratio = 70

--Delete automobile_data
--where compression_ratio = 70

--update automobile_data
--set 
--	num_of_cylinders = 'two'
--where
--	num_of_cylinders = 'tow'


--Select distinct drive_wheels
--from automobile_data

--Select max(price)
--from automobile_data

